package com.code.aon.ql.ast;


/**
 * Empty interface for identifying Expressions.
 *  
 * @author Consulting & Development. Ra�l Trepiana - 20-nov-2003
 * @since 1.0
 *  
 */
public interface Expression extends Criterion {

}